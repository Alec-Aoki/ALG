#include <iostream>
#include <utility>
#include <vector>
#include <algorithm>
#include <set>
#include <iomanip>
#include <cmath>
using namespace std;

/*
É dado um conjunto de pedras identificadas pelas propriedades:
    - Energia Arcana (E)
    - Vibração Mística (V)
Podendo ser interpretadas como um par de coordenadas num plano bidimensional.
O objetivo é definir o conjunto de pedras que formam o fecho convexo mínimo,
seguindo as regras:
    1. O fecho convexo deve ser percorrido no sentido anti-horário.
    2. O ponto inicial deve ser a pedra com menor valor de Ei.
    3. Em caso de empate no menor Ei, escolher a pedra com menor valor de Vi.
    4. Se houver colinearidade entre pedras na borda do fecho convexo, todas essas
    pedras devem ser incluídas na solução, respeitando a ordem crescente de Ei.
    5. Os valores de Ei e Vi devem ser considerados com até 4 casas decimais para fins de
    comparação.

Algoritmos para construção de fecho convexo:
    - Incremental
    - Gift wrapping
    - Varredura de Graham
    - Dividir e conquistar <--------

Divisão e conquista (https://www.geeksforgeeks.org/dsa/convex-hull-using-divide-and-conquer-algorithm/):
1. Ordena os pontos segundo coordenada x
2. Recursivamente
    2.1 Divide em dois conjuntos A e B de tamanho <= 5
    2.2 Constroi fechos de A e B
        2.3 Para <= 5, força bruta
    2.3 Combina conv (A) e conv (B)
        2.3.1 Tangente entre A e B
*/

vector<pair<float, float>> fecho_convexo(vector<pair<float, float>> poligono);
vector<pair<float, float>> forcaBruta(vector<pair<float, float>> poligono, pair<float, float> &meio);
vector<pair<float, float>> merge(vector<pair<float, float>> poligonoEsquerda,
                            vector<pair<float, float>> poligonoDireita);
bool comparar_angPolar(pair<float, float> p1, pair<float, float> q1, pair<float, float> meio);
int orientacao(pair<float, float> a, pair<float, float> b, pair<float, float> c);
vector<pair<float, float>> ordenar_antihorario(vector<pair<float, float>> pontos);

int main (void){
    int quantCasosTeste = 0;
    int quantPedras = 0;
    vector<pair<float, float>> vetor_pedras;
    float E; // Energia Arcana (x)
    float V; // Vibração Mística (y)

    cin >> quantCasosTeste;
    for(int i = 0; i < quantCasosTeste; i++){
        cin >> quantPedras;

        /* Leitura dos pares de coord. */
        for(int j = 0; j < quantPedras; j++){
            cin >> E >> V;
            // Inserindo cada par em vetor_pedras
            vetor_pedras.push_back(make_pair(E, V));
        }

        // Ordenando os pares de acordo com E (x)
        sort(vetor_pedras.begin(), vetor_pedras.end());

        vector<pair<float, float>> vetor_res = fecho_convexo(vetor_pedras);
        
        // Reordenar para começar do ponto com menor E (e menor V em caso de empate)
        vetor_res = ordenar_antihorario(vetor_res);

        cout << "Caso " << (i + 1) << ":" << endl;
        cout << "Tamanho do colar: " << vetor_res.size() << endl;
        cout << "Pedras ancestrais: ";
        cout << fixed << setprecision(4);
        for(int j = 0; j < vetor_res.size(); j++){
            cout << "(" << vetor_res[j].first << "," << vetor_res[j].second << ")";
            if(j < vetor_res.size() - 1){
                cout << ",";
            }
        }
        cout << endl << endl;

        /* Limpeza de variáveis */
        vetor_pedras.clear();
    }

    return 0;
}

/* Ordena o fecho convexo para começar do ponto correto e seguir anti-horário */
vector<pair<float, float>> ordenar_antihorario(vector<pair<float, float>> pontos){
    if(pontos.size() <= 1) return pontos;
    
    // Encontrar o ponto com menor E (x), e menor V (y) em caso de empate
    int idx_inicio = 0;
    for(int i = 1; i < pontos.size(); i++){
        if(pontos[i].first < pontos[idx_inicio].first ||
           (abs(pontos[i].first - pontos[idx_inicio].first) < 1e-4 && 
            pontos[i].second < pontos[idx_inicio].second)){
            idx_inicio = i;
        }
    }
    
    // Calcular centroide
    pair<float, float> centro = {0, 0};
    for(auto& p : pontos){
        centro.first += p.first;
        centro.second += p.second;
    }
    centro.first /= pontos.size();
    centro.second /= pontos.size();
    
    // Ordenar pelo ângulo polar em relação ao centroide
    sort(pontos.begin(), pontos.end(), 
        [&centro](const pair<float, float>& p1, const pair<float, float>& q1) {
            return comparar_angPolar(p1, q1, centro);
        });
    
    // Encontrar novamente o índice do ponto inicial após a ordenação
    idx_inicio = 0;
    for(int i = 1; i < pontos.size(); i++){
        if(pontos[i].first < pontos[idx_inicio].first ||
           (abs(pontos[i].first - pontos[idx_inicio].first) < 1e-4 && 
            pontos[i].second < pontos[idx_inicio].second)){
            idx_inicio = i;
        }
    }
    
    // Rotacionar o vetor para começar do ponto inicial
    vector<pair<float, float>> resultado;
    for(int i = 0; i < pontos.size(); i++){
        resultado.push_back(pontos[(idx_inicio + i) % pontos.size()]);
    }
    
    return resultado;
}

/* Fecho convexo por divisão e conquista */
vector<pair<float, float>> fecho_convexo(vector<pair<float, float>> poligono){
    pair<float, float> meio = {0,0};
    if(poligono.size() <= 5){
        return forcaBruta(poligono, meio);
    }

    /* Separando o polígono (divisão) */
    vector<pair<float, float>> poligonoEsquerda;
    vector<pair<float, float>> poligonoDireita;
    for(int i = 0; i < poligono.size()/2; i++){
        poligonoEsquerda.push_back(poligono[i]);
    }
    for(int i = poligono.size()/2; i < poligono.size(); i++){
        poligonoDireita.push_back(poligono[i]);
    }

    /* Recursão */
    vector<pair<float, float>> fechoEsquerda = fecho_convexo(poligonoEsquerda);
    vector<pair<float, float>> fechoDireita = fecho_convexo(poligonoDireita);

    return merge(fechoEsquerda, fechoDireita);
}

/* Fecho convexo por força bruta para 5 vértices ou menos */
vector<pair<float, float>> forcaBruta(vector<pair<float, float>> poligono,
                                pair<float, float> &meio){
    // Set para armazenar os pontos que compõem o fecho convexo
    set<pair<float, float>> set_pontosFecho;

    for(int i = 0; i < poligono.size(); i++){
        for(int j = i + 1; j < poligono.size(); j++){
            // Coordenadas do ponto 1
            float x1 = poligono[i].first;
            float y1 = poligono[i].second;

            // Coordenadas do ponto 2
            float x2 = poligono[j].first;
            float y2 = poligono[j].second;

            // ax + by + c = 0
            // Coeficientes a, b e c:
            float a = y1 - y2;
            float b = x2 - x1;
            float c = (x1 * y2) - (x2 * y1);

            // Contadores pra verificar se os pontos estão todos
            // em um mesmo lado
            int quantPontosLadoPositivo = 0;
            int quantPontosLadoNegativo = 0;

            // Verificando todos os pontos do polígono em relação
            // à reta atual
            for(int k = 0; k < poligono.size(); k++){
                float valorPosicao = (a * poligono[k].first) +
                                    (b * poligono[k].second) + c;

                if (valorPosicao <= 0) quantPontosLadoNegativo++;
                if (valorPosicao >= 0) quantPontosLadoPositivo++;
            }
            if (quantPontosLadoPositivo == poligono.size() ||
                quantPontosLadoNegativo == poligono.size()){
                    set_pontosFecho.insert(poligono[i]);
                    set_pontosFecho.insert(poligono[j]);
            }
        }
    }

    // Convertendo set para vetor
    vector<pair<float, float>> vetor_resultado;
    for(pair<float, float> ponto : set_pontosFecho){
        vetor_resultado.push_back(ponto);
    }

    /* Ordenando os pontos no sentido anti-horário */
    meio = {0, 0};
    int quantPontos = vetor_resultado.size();

    // Calculando o centroide (ponto médio)
    for(int i = 0; i < quantPontos; i++){
        meio.first += vetor_resultado[i].first;
        meio.second += vetor_resultado[i].second;

        // Multiplica pela quantidade de pontos para não perder precisão
        vetor_resultado[i].first *= quantPontos;
        vetor_resultado[i].second *= quantPontos;
    }

    // Ordenando usando ângulo polar
    sort(vetor_resultado.begin(), vetor_resultado.end(), 
        [&meio](const pair<float, float>& p1, const pair<float, float>& q1) {
            return comparar_angPolar(p1, q1, meio);
        });
    
    /* Restaurando as coordenadas originais */
    for(int i = 0; i < quantPontos; i++){
        vetor_resultado[i] = make_pair(vetor_resultado[i].first / quantPontos,
                                    vetor_resultado[i].second / quantPontos);
    } 

    return vetor_resultado;
}

/* Determina o quadrante de um ponto */
int quad(pair<float, float> p){
    if (p.first >= 0 && p.second >= 0)
        return 1;
    if (p.first <= 0 && p.second >= 0)
        return 2;
    if (p.first <= 0 && p.second <= 0)
        return 3;
    return 4;
}

bool comparar_angPolar(pair<float, float> p1, pair<float, float> q1, pair<float, float> meio){
    pair<float, float> p = make_pair(p1.first - meio.first,
                                p1.second - meio.second);
    pair<float, float> q = make_pair(q1.first - meio.first,
                                q1.second - meio.second);

    int um = quad(p);
    int dois = quad(q);

    if (um != dois)  return (um < dois);
    return (p.second*q.first < q.second*p.first);
}

/* Merge: achar a tangente entre os dois polígonos */
vector<pair<float, float>> merge(vector<pair<float, float>> poligonoEsquerda,
                            vector<pair<float, float>> poligonoDireita){
    int quantPontosEsquerda = poligonoEsquerda.size();
    int quantPontosDireita = poligonoDireita.size();

    // Encontrando ponto mais a direita do polígono esquerdo
    int ind_pontoMaisDireita = 0;
    for(int i = 1; i < quantPontosEsquerda; i++){
        if(poligonoEsquerda[i].first > poligonoEsquerda[ind_pontoMaisDireita].first){
            ind_pontoMaisDireita = i;
        }
    }

    // Encontrando ponto mais a esquerda do polígono direito
    int ind_pontoMaisEsquerda = 0;
    for(int i = 1; i < quantPontosDireita; i++){
        if(poligonoDireita[i].first < poligonoDireita[ind_pontoMaisEsquerda].first){
            ind_pontoMaisEsquerda = i;
        }
    }

    /* Encontrando a tangente superior */
    int ind_atualEsquerda = ind_pontoMaisDireita;
    int ind_atualDireita = ind_pontoMaisEsquerda;
    bool tangenteEncontrada = false;

    while(!tangenteEncontrada){
        tangenteEncontrada = true;
        
        // Percorrendo o polígono esquerdo no sentido anti-horário
        while(orientacao(poligonoDireita[ind_atualDireita],
                        poligonoEsquerda[ind_atualEsquerda],
                        poligonoEsquerda[(ind_atualEsquerda + 1) % quantPontosEsquerda]) >= 0){
            ind_atualEsquerda = (ind_atualEsquerda + 1) % quantPontosEsquerda;
        }

        // Percorrendo o polígono direito no sentido horário
        while(orientacao(poligonoEsquerda[ind_atualEsquerda],
                        poligonoDireita[ind_atualDireita],
                        poligonoDireita[(ind_atualDireita + 1) % quantPontosDireita]) <= 0){
            ind_atualDireita = (quantPontosDireita + ind_atualDireita - 1) % quantPontosDireita;
            tangenteEncontrada = false;
        }
    }

    // Armazenando os índices da tangente superior
    int ind_tangSupEsq = ind_atualEsquerda;
    int ind_tangSupDir = ind_atualDireita;

    /* Encontrando a tangente inferior */
    ind_atualEsquerda = ind_pontoMaisDireita;
    ind_atualDireita = ind_pontoMaisEsquerda;
    tangenteEncontrada = false;

    while(!tangenteEncontrada){
        tangenteEncontrada = true;

        // Percorrendo o polígono direito no sentido anti-horário
        while(orientacao(poligonoEsquerda[ind_atualEsquerda],
                        poligonoDireita[ind_atualDireita],
                        poligonoDireita[(ind_atualDireita + 1) % quantPontosDireita]) >= 0){
            ind_atualDireita = (ind_atualDireita + 1) % quantPontosDireita;
        }

        // Percorrendo o polígono esquerdo no sentido horário
        while(orientacao(poligonoDireita[ind_atualDireita],
                        poligonoEsquerda[ind_atualEsquerda],
                        poligonoEsquerda[(quantPontosEsquerda + ind_atualEsquerda - 1) % quantPontosEsquerda]) <= 0){
            ind_atualEsquerda = (quantPontosEsquerda + ind_atualEsquerda - 1) % quantPontosEsquerda;
            tangenteEncontrada = false;
        }
    }

    // Armazenando os índices da tangente inferior
    int ind_tangInfEsq = ind_atualEsquerda;
    int ind_tangInfDir = ind_atualDireita;

    /* Construindo o feixo convexo */
    vector<pair<float, float>> feixoResultante;

    // Adicionando os pontos do polígono esquerdo (da tangente superior até a inferior)
    int ind_percorrer = ind_tangSupEsq;
    feixoResultante.push_back(poligonoEsquerda[ind_tangSupEsq]);

    while(ind_percorrer != ind_tangInfEsq){
        ind_percorrer = (ind_percorrer + 1) % quantPontosEsquerda;
        feixoResultante.push_back(poligonoEsquerda[ind_percorrer]);
    }

    // Adicionando os pontos do polígono direito (da tangente inferior até a superior)
    ind_percorrer = ind_tangInfDir;
    feixoResultante.push_back(poligonoDireita[ind_tangInfDir]);

    while(ind_percorrer != ind_tangSupDir){
        ind_percorrer = (ind_percorrer + 1) % quantPontosDireita;
        feixoResultante.push_back(poligonoDireita[ind_percorrer]);
    }

    return feixoResultante;
}

// Verifica se a linha passa pelo polígono
int orientacao(pair<float, float> a, pair<float, float> b,
                pair<float, float> c){
    float res = (b.second-a.second)*(c.first-b.first) -
            (c.second-b.second)*(b.first-a.first);

            
    const float EPSILON = 1e-4;
    if (abs(res) < EPSILON)
        return 0;
    if (res > 0)
        return 1;
    return -1;
}